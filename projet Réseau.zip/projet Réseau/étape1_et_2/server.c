#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/stat.h>
#include <sys/types.h>

#define BUFFER_SIZE 516 // 4 octets d'en-tête + 512 octets de données max
#define SERVER_PORT 6969 // Port TFTP 69 par défaut
#define TIMEOUT 3       // Délai d'attente en secondes
#define MAX_ENVOI 5   // Nombre maximal de retransmissions
#define UPLOAD_DIR "reception/"  // Dossier de stockage des fichiers reçus

//fonction pour créer un dossier qui permet de stocker nos fichiers comme le dossier tftpboot pour les serveurs standard
void create_upload_dir() {
    struct stat st = {0};
    if (stat(UPLOAD_DIR, &st) == -1) {
        mkdir(UPLOAD_DIR, 0777); // Création du dossier avec permissions totales
    }
}

void requete_client(int sockfd) {
    char buffer[BUFFER_SIZE];
    struct sockaddr_in client_addr;
    socklen_t addr_len = sizeof(client_addr);
    //configuration du timeout
    struct timeval timeout = {TIMEOUT, 0};
    setsockopt(sockfd, SOL_SOCKET, SO_RCVTIMEO, &timeout, sizeof(timeout));

    while (1) {
        // Recevoir la requête du client
        int bytes_received = recvfrom(sockfd, buffer, BUFFER_SIZE, 0, (struct sockaddr *)&client_addr, &addr_len);
        if (bytes_received < 4) continue; // Paquet invalide, on ignore

        char filename[512];
        FILE *file;
        int block_number = 1;

        // Identifier la requête (RRQ ou WRQ)
        if (buffer[1] == 1) { // RRQ (Read Request)
            // Construire le chemin du fichier à partir du répertoire de téléchargement et du nom du fichier contenu dans le buffer
            snprintf(filename, sizeof(filename), "%s%s", UPLOAD_DIR, &buffer[2]);
            file = fopen(filename, "rb");
            if (!file) {
                perror("Erreur : Fichier non trouvé");
                continue;
            }

            // Envoyer le fichier au client
            while (1) {
                // Lire jusqu'à 512 octets du fichier dans le buffer à partir de la position 4 (espace réservé pour l'opcode et le numéro de bloc)
                int data_size = fread(&buffer[4], 1, 512, file);
                
                // Définir l'opcode DATA (pour indiquer qu'il s'agit d'un bloc de données)
                buffer[0] = 0;
                buffer[1] = 3; // Opcode DATA

                // Placer le numéro de bloc dans les 2 octets suivants du buffer (Big Endian)
                buffer[2] = (block_number >> 8) & 0xFF;
                buffer[3] = block_number & 0xFF;

                int retries = 0;
                while (retries < MAX_ENVOI) {
                    // Envoyer le bloc de données au client
                    sendto(sockfd, buffer, data_size + 4, 0, (struct sockaddr *)&client_addr, addr_len);
                    printf("Bloc %d envoyé (tentative %d)\n", block_number, retries + 1);

                   // Attendre la réception de l'ACK du client
                    int ack_size = recvfrom(sockfd, buffer, BUFFER_SIZE, 0, (struct sockaddr *)&client_addr, &addr_len);
                    
                    // Vérifier si l'ACK reçu est valide et correspond au numéro de bloc
                    if (ack_size > 0 && buffer[1] == 4 &&
                        (buffer[2] << 8 | buffer[3]) == block_number) {
                        break; // ACK reçu, on passe au bloc suivant
                    }

                    printf("Aucune réponse, retransmission...\n");
                    retries++;
                }

                if (retries == MAX_ENVOI) {
                    printf("Erreur : Client ne répond pas après %d tentatives\n", MAX_ENVOI);
                    break;
                }

                // Fin de fichier
                if (data_size < 512) break;
                block_number++;
            }

            fclose(file);
            printf("Fichier envoyé : %s\n", filename);

        } else if (buffer[1] == 2) { // WRQ (Write Request)
            // Construire le chemin du fichier à partir du répertoire de téléchargement et du nom du fichier contenu dans le buffer
            snprintf(filename, sizeof(filename), "%s%s", UPLOAD_DIR, &buffer[2]);
            file = fopen(filename, "wb");
            if (!file) {
                perror("Erreur : Impossible d'écrire le fichier");
                continue;// Passer à la prochaine requête si l'ouverture échoue
            }

            // Envoi ACK initial pour démarrer la transmission
            buffer[0] = 0;
            buffer[1] = 4; // Opcode ACK
            buffer[2] = 0;
            buffer[3] = 0;
            sendto(sockfd, buffer, 4, 0, (struct sockaddr *)&client_addr, addr_len);

            // Réception des paquets DATA
            while (1) {
                int retries = 0;
                int bytes_received;
                
                while (retries < MAX_ENVOI) {
                    bytes_received = recvfrom(sockfd, buffer, BUFFER_SIZE, 0, (struct sockaddr *)&client_addr, &addr_len);
                    if (bytes_received > 4 && buffer[1] == 3) break; // Paquet DATA valide reçu

                    printf("Aucune réponse, attente du bloc %d (tentative %d)...\n", block_number, retries + 1);
                    retries++;
                }

                if (retries == MAX_ENVOI) {
                    printf("Erreur : Client ne répond pas après %d tentatives\n", MAX_ENVOI);
                    break;
                }

                // Vérification du bloc reçu
                int received_block = (buffer[2] << 8) | buffer[3];
                if (received_block != block_number) {
                    printf("Bloc inattendu reçu : attendu=%d, reçu=%d\n", block_number, received_block);
                    continue;
                }

                // Écriture des données dans le fichier
                fwrite(&buffer[4], 1, bytes_received - 4, file);

                // Envoi de l'ACK
                buffer[0] = 0;
                buffer[1] = 4; // Opcode ACK
                buffer[2] = (block_number >> 8) & 0xFF;
                buffer[3] = block_number & 0xFF;
                sendto(sockfd, buffer, 4, 0, (struct sockaddr *)&client_addr, addr_len);
                printf("ACK envoyé pour le bloc %d\n", block_number);

                // Fin du transfert
                if (bytes_received - 4 < 512) break;

                block_number++;
            }

            fclose(file);
            printf("Fichier reçu et stocké : %s\n", filename);
        }
    }
}

int main() {
    // Créer le dossier de reception "reception/" s'il n'existe pas

    create_upload_dir();

    int sockfd = socket(AF_INET, SOCK_DGRAM, 0);
    if (sockfd < 0) {
        perror("Erreur de création de la socket");
        exit(EXIT_FAILURE);
    }

    //initialisation du  socket
    struct sockaddr_in server_addr;
    memset(&server_addr, 0, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(SERVER_PORT);
    server_addr.sin_addr.s_addr = INADDR_ANY;

    // La fonction bind associe l'adresse IP et le port spécifiés dans la structure sockaddr_in
    // au socket identifié par sockfd. Cette opération permet de lier le socket à une adresse
    // spécifique afin que le système sache où envoyer ou recevoir des données pour ce socket.



    if (bind(sockfd, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
        perror("Erreur de liaison de la socket");
        close(sockfd);
        exit(EXIT_FAILURE);
    }

    printf("Serveur TFTP en attente sur le port %d...\n", SERVER_PORT);
    requete_client(sockfd);

    close(sockfd);
    return 0;
}
