#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <errno.h>

#define BUFFER_SIZE 516// 512 bytes pour les données et 4 bytes pour opcode et le nombre de bloc

// definition des opcodes selon la norme rfc
#define OPCODE_RRQ 1
#define OPCODE_WRQ 2
#define OPCODE_DATA 3
#define OPCODE_ACK 4
#define OPCODE_ERROR 5
// port par défaut 69 pour l'écoute en local avec les serveurs standard
#define DEFAULT_PORT 6969
#define TEMPS 5 // Timeout en secondes
#define MAX_ENVOI 3 // Nombre maximal de retransmissions

/*Description des fonctions utilisées*/

//sendto
// Envoie la requête RRQ (Read Request) au serveur TFTP via UDP.
// - `sockfd` : Descripteur de socket utilisé pour la communication.
// - `buffer` : Contient la requête RRQ formatée (opcode, nom de fichier, mode de transfert).
// - `rrq_len` : Taille effective des données à envoyer depuis `buffer`.
// - `0` : Options supplémentaires (non utilisées ici, donc mises à 0).
// - `(struct sockaddr *)server_addr` : Adresse du serveur à qui envoyer la requête.
// - `server_addr_len` : Taille de la structure `server_addr` (obligatoire pour `sendto`).
// Si l’envoi échoue, la fonction retourne `-1`, indiquant une erreur réseau.

//recevfrom
// Réception d'un message UDP du serveur TFTP.
// - `sockfd` : Socket utilisée pour la communication.  
// - `buffer` : Stocke les données reçues.  
// - `BUFFER_SIZE` : Taille maximale du buffer.  
// - `0` : Options (non utilisées ici).  
// - `(struct sockaddr *)server_addr` : Adresse source (serveur).  
// - `&server_addr_len` : Taille de l'adresse source.  
// Retourne le nombre d'octets reçus ou `-1` en cas d'erreur.

//fonction pour la gestion des erreurs 
void gest_erreur(const char *message) {
    perror(message);
    exit(EXIT_FAILURE);
}


void configure_timeout(int sockfd, int timeout) {
    struct timeval tv;
    tv.tv_sec = timeout;
    tv.tv_usec = 0;//définit la partie microseconde comme utilise que des secondes
    //permet de configurer les délais d'attente sur le socket via l'option SO_RCVTIMEO(time en réception)
    if (setsockopt(sockfd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv)) < 0) {
        gest_erreur("Erreur de configuration du timeout");
    }
}


// Cette fonction envoie une requête de lecture (RRQ) à un serveur TFTP pour récupérer un fichier spécifié.
// Elle gère les retransmissions en cas de timeout et assure la réception des blocs de données envoyés par le serveur.
// Si la réponse du serveur est reçue, elle écrit les données dans un fichier local. Sinon, elle effectue plusieurs tentatives de transmission de la requête.
// En cas de succès, le fichier est transféré intégralement, sinon des messages d'erreur sont affichés en cas de défaillance.
// Paramètres:
// - sockfd : Descripteur de la socket UDP utilisée pour la communication.
// - server_addr : Adresse du serveur TFTP (struct sockaddr_in).
// - filename : Nom du fichier à récupérer du serveur.


void send_rrq(int sockfd, struct sockaddr_in *server_addr, const char *filename) {
    char buffer[BUFFER_SIZE];
    socklen_t server_addr_len = sizeof(*server_addr);
    
    // Configuration du timeout sur la socket
    configure_timeout(sockfd, TEMPS);

    // Construction de la requête RRQ

// Construction de la requête RRQ (Read Request) en utilisant le format "%c%c%s%c%s%c" : 
// 1. Le premier "%c" insère un octet nul pour indiquer le début de la requête.
// 2. Le deuxième "%c" insère l'opcode de la requête (OPCODE_RRQ) pour spécifier l'opération "Read Request".
// 3. "%s" insère le nom du fichier que l'on souhaite récupérer.
// 4. Le quatrième "%c" insère un octet nul pour marquer la fin du nom du fichier.
// 5. "%s" insère le mode de transfert ("octet").
// 6. Le dernier "%c" insère un octet nul marquant la fin de la chaîne de la requête.
// La longueur de la requête est stockée dans rrq_len, ce qui permet de savoir combien de bytes ont été écrits dans le buffer.

    int rrq_len = snprintf(buffer, sizeof(buffer), "%c%c%s%c%s%c", 
     0, OPCODE_RRQ, filename, 0, "octet", 0);
    
    // Envoi de la requête RRQ avec gestion des timeouts
    int essai = 0;
    while (essai < MAX_ENVOI) {
        if (sendto(sockfd, buffer, rrq_len, 0, (struct sockaddr *)server_addr, server_addr_len) < 0) {
            perror("Erreur lors de l'envoi de la requête RRQ");
            exit(1);
        }
        
        printf("Requête RRQ envoyée (tentative %d) pour le fichier : %s\n", essai + 1, filename);
        
        // Attente de la première réponse du serveur
        int recv_len = recvfrom(sockfd, buffer, BUFFER_SIZE, 0, 
            (struct sockaddr *)server_addr, &server_addr_len);
        if (recv_len >= 0) {
            break; // Le serveur a répondu
        }
        
        printf("Aucune réponse du serveur, nouvelle tentative...\n");
        essai++;
    }

    if (essai == MAX_ENVOI) {
        printf("Erreur : le serveur ne répond pas après %d tentatives.\n", MAX_ENVOI);
        exit(1);
    }

    // Création du fichier pour écrire les données reçues
    FILE *file = fopen(filename, "wb");
    if (!file) {
        perror("Erreur lors de l'ouverture du fichier");
        exit(1);
    }

    int block_number = 1;
    int recv_len;

    while (1) {
        essai = 0;

        while (essai < MAX_ENVOI) {
           
            recv_len = recvfrom(sockfd, buffer, BUFFER_SIZE, 0, 
                (struct sockaddr *)server_addr, &server_addr_len);
            if (recv_len >= 0) {
                break; // Réception réussie
            }

            printf("Timeout lors de la réception du bloc %d, tentative %d...\n", block_number, essai + 1);
            essai++;
        }

        if (essai == MAX_ENVOI) {
            printf("Erreur : échec de réception du bloc %d après %d tentatives.\n", block_number, MAX_ENVOI);
            fclose(file);
            exit(1);
        }

        // Extraction de l'opcode et du numéro de bloc
        int opcode = (buffer[0] << 8) | buffer[1];
        int received_block = (buffer[2] << 8) | buffer[3];

        if (opcode != OPCODE_DATA || received_block != block_number) {
            printf("Bloc inattendu reçu : opcode=%d, block=%d\n", opcode, received_block);
            continue;
        }

        // Écriture des données dans le fichier
        // Les 4 premiers octets du buffer contiennent l'opcode et le numéro de bloc,
        // donc les données utiles commencent à partir de buffer + 4.
        // - buffer + 4 : Décale le pointeur pour ignorer l'en-tête TFTP.
        // - recv_len - 4 : Évite d'écrire l'opcode et le numéro de bloc dans le fichier.
        fwrite(buffer + 4, 1, recv_len - 4, file);
        printf("Reçu et écrit le bloc %d\n", block_number);

        // Envoi de l'ACK
        char ack[4];
        ack[0] = 0; // Premier octet à 0 
        ack[1] = OPCODE_ACK; // Opcode ACK (0x04)
        ack[2] = (block_number >> 8) & 0xFF;// Extraction du premier octet du numéro de bloc (8 bits de poids fort)
        ack[3] = block_number & 0xFF;// Extraction du deuxième octet du numéro de bloc (_ bits de poids faible)
        // Cela garantit que le numéro de bloc est envoyé en Big Endian, comme requis par TFTP.

        if (sendto(sockfd, ack, sizeof(ack), 0, 
         (struct sockaddr *)server_addr, server_addr_len) < 0) {
            perror("Erreur lors de l'envoi de l'ACK");
        fclose(file);
        exit(1);
    }

    printf("ACK envoyé pour le bloc %d\n", block_number);

        // Si la taille du dernier paquet de données est < 512, fin du transfert
        if (recv_len < 516) {  // 512 données + 4 en-tête
            printf("Transfert terminé. Dernier bloc reçu : %d\n", block_number);
            break;
        }

        block_number++;
    }

    fclose(file);
}



// Cette fonction envoie une requête d'écriture (WRQ) à un serveur TFTP pour transférer un fichier spécifié.
// Elle gère les retransmissions en cas de timeout et assure la transmission des blocs de données au serveur.
// Si le serveur répond et accepte le fichier, la fonction continue d'envoyer les blocs jusqu'à ce que le transfert soit complet.
// En cas de timeout ou d'erreur, la fonction réessaie plusieurs fois avant d'abandonner et d'afficher un message d'erreur.
// Paramètres:
// - sockfd : Descripteur de la socket UDP utilisée pour la communication.
// - server_addr : Adresse du serveur TFTP (struct sockaddr_in).
// - filename : Nom du fichier à transférer vers le serveur.



void send_wrq(int sockfd, struct sockaddr_in *server_addr, const char *filename) {
    FILE *file = fopen(filename, "rb"); // Ouvre le fichier en mode lecture binaire
    if (!file) {
        perror("Erreur : Impossible d'ouvrir le fichier à envoyer");
        exit(EXIT_FAILURE);
    }

    char buffer[BUFFER_SIZE]; 
    socklen_t addr_len = sizeof(*server_addr);
    int block_number = 0;
    int essai;
    ssize_t bytes_received;

    // Construction de la requête WRQ similaire au snprintf dans la partie rrq
    buffer[0] = 0;
    buffer[1] = OPCODE_WRQ;
    strcpy(&buffer[2], filename);
    strcpy(&buffer[2 + strlen(filename) + 1], "octet"); // Mode binaire
    int len = 2 + strlen(filename) + 1 + strlen("octet") + 1;

    // Envoi de la requête WRQ avec retransmission en cas de perte
    essai = 0;
    while (essai < MAX_ENVOI) {
        if (sendto(sockfd, buffer, len, 0, (struct sockaddr *)server_addr, addr_len) < 0) {
            perror("Erreur d'envoi de WRQ");
            fclose(file);
            exit(EXIT_FAILURE);
        }

        // Attente de l'ACK (acknowledgment) pour WRQ
        bytes_received = recvfrom(sockfd, buffer, BUFFER_SIZE, 0, (struct sockaddr *)server_addr, &addr_len);
        if (bytes_received > 0) {
            break; // Réponse reçue, sortie de la boucle
        }

        if (errno == EAGAIN || errno == EWOULDBLOCK) {
            fprintf(stderr, "Timeout atteint pour l'ACK de WRQ. Réessai...\n");
            essai++;
        } else {
            perror("Erreur lors de la réception de l'ACK de WRQ");
            fclose(file);
            exit(EXIT_FAILURE);
        }
    }

    if (essai == MAX_ENVOI) {
        fprintf(stderr, "Nombre maximal de retransmissions atteint. Échec de la requête WRQ.\n");
        fclose(file);
        return;
    }

    // Boucle pour envoyer le fichier en blocs de 512 octets
    block_number = 1;
    size_t bytes_read;
    while ((bytes_read = fread(buffer + 4, 1, 512, file)) > 0) {
        buffer[0] = 0;
        buffer[1] = OPCODE_DATA;
        buffer[2] = (block_number >> 8) & 0xFF;
        buffer[3] = block_number & 0xFF;

        essai = 0;
        while (essai < MAX_ENVOI) {
            if (sendto(sockfd, buffer, bytes_read + 4, 0, (struct sockaddr *)server_addr, addr_len) < 0) {
                perror("Erreur d'envoi des données");
                fclose(file);
                exit(EXIT_FAILURE);
            }

            // Attente de l'ACK pour le bloc envoyé
            bytes_received = recvfrom(sockfd, buffer, BUFFER_SIZE, 0, (struct sockaddr *)server_addr, &addr_len);
            if (bytes_received > 0) {
                int opcode = buffer[1];
                int received_block = (buffer[2] << 8) | buffer[3];

                if (opcode == OPCODE_ACK && received_block == block_number) {
                    block_number++;
                    break; // ACK reçu, envoi du prochain bloc
                } else if (opcode == OPCODE_ERROR) {
                    fprintf(stderr, "Erreur reçue du serveur : %s\n", buffer + 4);
                    fclose(file);
                    return;
                }
            }
            // Vérifie si l'erreur est due à un timeout (EAGAIN(try again) ou EWOULDBLOCK(Operation Would Block) : aucune réponse du serveur dans le délai imparti) et réessaie l'envoi.
            // EAGAIN : L'opération ne peut pas être complétée immédiatement et doit être réessayée ultérieurement.
            // EWOULDBLOCK : L'exécution de l'opération est temporairement impossible, en attente de la disponibilité d'une ressource.
            if (errno == EAGAIN || errno == EWOULDBLOCK) {
                fprintf(stderr, "Timeout atteint pour l'ACK du bloc %d. Réessai...\n", block_number);
                essai++;
            } else {
                perror("Erreur lors de la réception de l'ACK");
                fclose(file);
                exit(EXIT_FAILURE);
            }
        }

        if (essai == MAX_ENVOI) {
            fprintf(stderr, "Nombre maximal de retransmissions atteint. Échec de l'envoi du fichier.\n");
            fclose(file);
            return;
        }
    }

    fclose(file);
    printf("Fichier %s envoyé avec succès.\n", filename);
}

int main(int argc, char *argv[]) {
    if (argc < 4) {
        fprintf(stderr, "Usage: %s <server_ip> <mode> <filename>\n", argv[0]);
        fprintf(stderr, "<mode>: 'put' ou 'get'\n");
        exit(EXIT_FAILURE);
    }

    const char *server_ip = argv[1];
    const char *mode = argv[2];// put ou get
    const char *filename = argv[3];// nom du fichier 

    int sockfd;
    struct sockaddr_in server_addr;

    if ((sockfd = socket(AF_INET, SOCK_DGRAM, 0)) < 0) {
        gest_erreur("Erreur de création du socket");
    }

    configure_timeout(sockfd, TEMPS);
    //Initialisation de l'adresse du serveur
    memset(&server_addr, 0, sizeof(server_addr));
   // Définit la famille d'adresses comme AF_INET, indiquant que nous utilisons le protocole IPv4.
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(DEFAULT_PORT);
    if (inet_pton(AF_INET, server_ip, &server_addr.sin_addr) <= 0) {
        gest_erreur("Adresse IP invalide");
    }

    if (strcmp(mode, "get") == 0) {
        send_rrq(sockfd, &server_addr, filename);
    } else if (strcmp(mode, "put") == 0) {
        send_wrq(sockfd, &server_addr, filename);
    } else {
        fprintf(stderr, "Mode invalide : 'get' ou 'put'\n");
        close(sockfd);
        exit(EXIT_FAILURE);
    }

    close(sockfd);
    return 0;
}
