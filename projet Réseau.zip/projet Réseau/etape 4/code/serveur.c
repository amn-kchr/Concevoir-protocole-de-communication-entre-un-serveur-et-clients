/*
 * Explication des fonctions ntohl et htonl :
 *
 * ntohl :
 * - Cette fonction prend un entier 32 bits en ordre d'octets réseau (big-endian) et le convertit en
 *   ordre d'octets hôte (little-endian).
 *
 * htonl :
 * - Cette fonction prend un entier 32 bits en ordre d'octets hôte (little-endian sur la plupart des systèmes)
 *   et le convertit en ordre d'octets réseau (big-endian).
 * - Utilisée principalement pour préparer les données à être envoyées sur le réseau.
 *   
 Ces fonctions sont utilisées dans tout ce code et nous permis d'éviter de faire les décalages à chaque fois 
 comme dans les autres parties, cela sont des fonctions prédéfinies qui assure que le format big endian est
 bien respecté.
 */

// Inclusion des bibliothèques nécessaires
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <pthread.h>
#include <errno.h>

// Définition des constantes
#define BUFFER_SIZE 518    // 6 octets d'en-tête (bigfile) + 512 octets de données max
#define SERVER_PORT 6969   // Port TFTP alternatif (au lieu de 69)
#define TIMEOUT 3          // Délai d'attente en secondes
#define MAX_ENVOI 5        // Nombre maximal de retransmissions
#define UPLOAD_DIR "reception/"  // Dossier de stockage des fichiers

// Structure pour gérer les verrous en lecture/écriture par fichier
typedef struct file_lock {
    char filename[512];              // Nom du fichier
    pthread_rwlock_t rwlock;         // Verrou en lecture/écriture
    struct file_lock *next;          // Pointeur vers le prochain verrou
} file_lock;

file_lock *file_lock_list = NULL;    // Liste des verrous de fichiers
pthread_mutex_t file_lock_list_mutex = PTHREAD_MUTEX_INITIALIZER;  // Mutex pour protéger l'accès à la liste des verrous

// Création du dossier de réception s'il n'existe pas
void create_upload_dir() {
    struct stat st = {0};
    if (stat(UPLOAD_DIR, &st) == -1) {
        mkdir(UPLOAD_DIR, 0777);     // Création du dossier avec les permissions 0777
    }
}

// Récupère (ou crée) le verrou en lecture/écriture associé à un fichier
pthread_rwlock_t *get_file_lock(const char *filename) {
    pthread_mutex_lock(&file_lock_list_mutex);  // Verrouillage du mutex pour accéder à la liste des verrous
    file_lock *entry = file_lock_list;
    while (entry) {
        if (strcmp(entry->filename, filename) == 0) {  // Si le verrou existe déjà
            pthread_mutex_unlock(&file_lock_list_mutex);  // Déverrouillage du mutex
            return &entry->rwlock;  // Retourne le verrou existant
        }
        entry = entry->next;
    }
    entry = malloc(sizeof(file_lock));  // Allocation mémoire pour un nouveau verrou
    if (!entry) {
        perror("Erreur d'allocation pour le verrou de fichier");
        pthread_mutex_unlock(&file_lock_list_mutex);  // Déverrouillage du mutex en cas d'erreur
        return NULL;
    }
    strcpy(entry->filename, filename);  // Copie du nom de fichier
    pthread_rwlock_init(&entry->rwlock, NULL);  // Initialisation du verrou
    entry->next = file_lock_list;  // Ajout du nouveau verrou en tête de liste
    file_lock_list = entry;
    pthread_mutex_unlock(&file_lock_list_mutex);  // Déverrouillage du mutex
    return &entry->rwlock;  // Retourne le nouveau verrou
}

// Structure pour transmettre les infos du client au thread
typedef struct {
    struct sockaddr_in client_addr;  // Adresse du client
    socklen_t addr_len;              // Longueur de l'adresse
    char buffer[BUFFER_SIZE];        // Buffer pour les données
    int buffer_size;                 // Taille des données dans le buffer
    int bigfile_enabled;             // 0 = mode standard, 1 = option bigfile activée
} info_client;

// Fonction exécutée par chaque thread pour gérer un client
void *handle_client(void *arg) {
    info_client *client = (info_client *)arg;  // Conversion de l'argument en pointeur vers info_client
    
    // Création d'une nouvelle socket UDP pour cette session
    int sockfd = socket(AF_INET, SOCK_DGRAM, 0);
    if (sockfd < 0) {
        perror("Erreur de création de la socket (thread)");
        free(client);  // Libération de la mémoire allouée pour le client
        pthread_exit(NULL);  // Fin du thread
    }
    
    // Configuration du timeout pour la socket
    struct timeval timeout = {TIMEOUT, 0};
    setsockopt(sockfd, SOL_SOCKET, SO_RCVTIMEO, &timeout, sizeof(timeout));
    
    char *buffer = client->buffer;
    struct sockaddr_in client_addr = client->client_addr;
    socklen_t addr_len = client->addr_len;
    int request_size = client->buffer_size;
    
    free(client);  // Libération de la structure client après copie des données locales
    
    // --- Parsing de la requête TFTP ---
    // Format TFTP (RRQ/WRQ) : [2 octets opcode] [nom de fichier] 0 [mode] 0 [option1] 0 [valeur1] 0 ...
    int opcode = buffer[1];  // 1 = RRQ, 2 = WRQ
    char filename[512];
    memset(filename, 0, sizeof(filename));
    strncpy(filename, buffer+2, sizeof(filename)-1);
    // Avancer le pointeur après le nom de fichier et le 0
    int pos = 2 + strlen(buffer+2) + 1;
    
    // Récupérer le mode (par ex. "octet")
    char mode[12];
    memset(mode, 0, sizeof(mode));
    strncpy(mode, buffer+pos, sizeof(mode)-1);
    pos += strlen(mode) + 1;
    
    // Traitement des options (si présentes)
    int options_present = 0;
    int bigfile_enabled = 0;
    while (pos < request_size && buffer[pos] != '\0') {
        options_present = 1;  // Indique que des options sont présentes dans la requête
        char option[50];  // Variable pour stocker le nom de l'option
        char value[50];  // Variable pour stocker la valeur de l'option
        memset(option, 0, sizeof(option));  // Initialise la variable option à zéro
        memset(value, 0, sizeof(value));  // Initialise la variable value à zéro
        strncpy(option, buffer + pos, sizeof(option) - 1);  // Copie le nom de l'option depuis le buffer
        pos += strlen(option) + 1;  // Avance le pointeur après le nom de l'option et le caractère nul
        if (pos < request_size) {  // Vérifie s'il reste des données dans la requête
            strncpy(value, buffer + pos, sizeof(value) - 1);  // Copie la valeur de l'option depuis le buffer
            pos += strlen(value) + 1;  // Avance le pointeur après la valeur de l'option et le caractère nul
        }
        // Vérifie si l'option est "bigfile" et si la valeur est "1"
        if (strcasecmp(option, "bigfile") == 0 && strcmp(value, "1") == 0) {
            bigfile_enabled = 1;  // Active le mode "bigfile"
        }
    }
    // Enregistrer le mode bigfile dans la structure
    // (utile pour le transfert ultérieur)
    int header_length = bigfile_enabled ? 6 : 4;
    
    // Si des options ont été négociées, envoyer un paquet OACK
    if (options_present) {
        char oack[BUFFER_SIZE];  // Buffer pour le paquet OACK
        int oack_len = 0;  // Longueur initiale du paquet OACK
        oack[oack_len++] = 0;  // Premier octet de l'en-tête
        oack[oack_len++] = 6;  // Opcode pour OACK

        // Si l'option "bigfile" est activée, ajouter cette option au paquet OACK
        if (bigfile_enabled) {
            strcpy(&oack[oack_len], "bigfile");  // Ajoute le nom de l'option "bigfile"
            oack_len += strlen("bigfile");  // Met à jour la longueur du paquet
            oack[oack_len++] = '\0';  // Ajoute le caractère nul après le nom de l'option
            strcpy(&oack[oack_len], "1");  // Ajoute la valeur de l'option "1"
            oack_len += strlen("1");  // Met à jour la longueur du paquet
            oack[oack_len++] = '\0';  // Ajoute le caractère nul après la valeur de l'option
        }

        // Envoie le paquet OACK au client
        sendto(sockfd, oack, oack_len, 0, (struct sockaddr *)&client_addr, addr_len);

        // Attente de l'ACK pour le bloc 0
        int ack_received = 0;  // Indicateur pour vérifier si l'ACK a été reçu
        for (int essai = 0; essai < MAX_ENVOI; essai++) {  // Boucle de tentatives de réception de l'ACK
            int ack_size = recvfrom(sockfd, buffer, BUFFER_SIZE, 0, (struct sockaddr *)&client_addr, &addr_len);
            if (ack_size > 0 && buffer[1] == 4) {  // Vérifie si un paquet ACK a été reçu
                if (bigfile_enabled && ack_size >= 6) {  // Si le mode "bigfile" est activé et la taille de l'ACK est correcte
                    unsigned int ack_block;
                    memcpy(&ack_block, &buffer[2], 4);  // Copie les 4 octets du numéro de bloc
                    ack_block = ntohl(ack_block);  // Convertit le numéro de bloc en ordre d'octets hôte
                    if (ack_block == 0) {  // Vérifie si le numéro de bloc est 0
                        ack_received = 1;  // Indique que l'ACK a été reçu
                        break;  // Sort de la boucle
                    }
                } else if (!bigfile_enabled && ack_size >= 4) {  // Si le mode "bigfile" n'est pas activé et la taille de l'ACK est correcte
                    if (buffer[2] == 0 && buffer[3] == 0) {  // Vérifie si le numéro de bloc est 0
                        ack_received = 1;  // Indique que l'ACK a été reçu
                        break;  // Sort de la boucle
                    }
                }
            }
        }

        // Si l'ACK n'a pas été reçu après plusieurs tentatives, afficher une erreur et quitter
        if (!ack_received) {
            printf("Erreur: Pas de ACK pour OACK\n");
            close(sockfd);  // Ferme la socket
            pthread_exit(NULL);  // Quitte le thread
        }
    }
    
    // Construit le chemin complet du fichier
    char fullpath[512];
    snprintf(fullpath, sizeof(fullpath), "%s%s", UPLOAD_DIR, filename);
    
    int block_number = 1;
    FILE *file;
    
    // Obtenir le verrou (read/write) associé au fichier
    pthread_rwlock_t *file_lock = get_file_lock(fullpath);
    if (!file_lock) {
         close(sockfd);
         pthread_exit(NULL);
    }
    
    // Pour une RRQ (lecture), on prend un verrou en lecture (partagé)
    // Pour une WRQ (écriture), on prend un verrou en écriture (exclusif)
    if (opcode == 1) {
        if (pthread_rwlock_rdlock(file_lock) != 0) {
            perror("Erreur lors de l'acquisition du verrou en lecture");
            close(sockfd);
            pthread_exit(NULL);
        }
    } else if (opcode == 2) {
        if (pthread_rwlock_wrlock(file_lock) != 0) {
            perror("Erreur lors de l'acquisition du verrou en écriture");
            close(sockfd);
            pthread_exit(NULL);
        }
    }
    
    if (opcode == 1) { // RRQ (lecture)
         file = fopen(fullpath, "rb");
         if (!file) {
             // Si le fichier n'est pas trouvé, envoi d'un paquet ERROR au client
             char error_pkt[BUFFER_SIZE];
             int err_len = 0;
             error_pkt[err_len++] = 0;
             error_pkt[err_len++] = 5; // ERROR
             error_pkt[err_len++] = 0;
             error_pkt[err_len++] = 1; // Code 1: Fichier non trouvé
             strcpy(&error_pkt[err_len], "Fichier non trouvé");
             err_len += strlen("Fichier non trouvé");
             error_pkt[err_len++] = 0;
             sendto(sockfd, error_pkt, err_len, 0, (struct sockaddr *)&client_addr, addr_len);
             pthread_rwlock_unlock(file_lock);
             close(sockfd);
             pthread_exit(NULL);
         }
         
         // Transfert du fichier par blocs de 512 octets
         while (1) {
             int data_size = fread(buffer + header_length, 1, 512, file);
             buffer[0] = 0;
             buffer[1] = 3; // DATA
             if (bigfile_enabled) {
                 unsigned int bn = htonl(block_number);
                 memcpy(&buffer[2], &bn, 4);
             } else {
                 buffer[2] = (block_number >> 8) & 0xFF;
                 buffer[3] = block_number & 0xFF;
             }
             int packet_size = header_length + data_size;
             
             int essai = 0;  // Déclaration et initialisation de la variable essai
             while (essai < MAX_ENVOI) {  // Boucle de tentatives d'envoi du paquet de données
                 sendto(sockfd, buffer, packet_size, 0, (struct sockaddr *)&client_addr, addr_len);  // Envoie le paquet de données au client
                 printf("Bloc %d envoyé (tentative %d) à %s:%d\n", block_number, essai + 1,
                        inet_ntoa(client_addr.sin_addr), ntohs(client_addr.sin_port));  // Affiche un message indiquant l'envoi du bloc

                 int ack_size = recvfrom(sockfd, buffer, BUFFER_SIZE, 0, (struct sockaddr *)&client_addr, &addr_len);  // Attente de l'ACK du client
                 if (ack_size > 0 && buffer[1] == 4) {  // Vérifie si un paquet ACK a été reçu
                     if (bigfile_enabled && ack_size >= 6) {  // Si le mode "bigfile" est activé et la taille de l'ACK est correcte
                         unsigned int ack_block;
                         memcpy(&ack_block, &buffer[2], 4);  // Copie les 4 octets du numéro de bloc
                         ack_block = ntohl(ack_block);  // Convertit le numéro de bloc en ordre d'octets hôte
                         if (ack_block == block_number) break;  // Si le numéro de bloc est correct, sort de la boucle
                     } else if (!bigfile_enabled && ack_size >= 4) {  // Si le mode "bigfile" n'est pas activé et la taille de l'ACK est correcte
                         int ack_block = (buffer[2] << 8) | buffer[3];  // Récupère le numéro de bloc à partir des 2 octets
                         if (ack_block == block_number) break;  // Si le numéro de bloc est correct, sort de la boucle
                     }
                 }
                 printf("Aucune réponse pour bloc %d, retransmission...\n", block_number);  // Affiche un message indiquant la retransmission du bloc
                 essai++;  // Incrémente le compteur de tentatives
             }

             if (essai == MAX_ENVOI) {  // Si le nombre maximal de tentatives est atteint
                 printf("Erreur : Client ne répond pas après %d tentatives pour le bloc %d\n", MAX_ENVOI, block_number);  // Affiche un message d'erreur
                 break;  // Sort de la boucle
             }

             if (data_size < 512) break;  // Fin de fichier si la taille des données est inférieure à 512 octets
             block_number++;  // Incrémente le numéro de bloc pour le prochain envoi
         }

         fclose(file);  // Ferme le fichier
         pthread_rwlock_unlock(file_lock);  // Libère le verrou en lecture/écriture
         printf("Fichier envoyé : %s\n", fullpath);  // Affiche un message indiquant que le fichier a été envoyé

    } else if (opcode == 2) { // WRQ (écriture)
         file = fopen(fullpath, "wb");
         if (!file) {
             char error_pkt[BUFFER_SIZE];
             int err_len = 0;
             error_pkt[err_len++] = 0;
             error_pkt[err_len++] = 5; // ERROR
             error_pkt[err_len++] = 0;
             error_pkt[err_len++] = 2; // Code 2: Écriture impossible
             strcpy(&error_pkt[err_len], "Impossible d'écrire le fichier");
             err_len += strlen("Impossible d'écrire le fichier");
             error_pkt[err_len++] = 0;
             sendto(sockfd, error_pkt, err_len, 0, (struct sockaddr *)&client_addr, addr_len);
             pthread_rwlock_unlock(file_lock);
             close(sockfd);
             pthread_exit(NULL);
         }
         
         // Pour WRQ, si aucune option n'a été négociée, envoyer l'ACK initial (bloc 0)
         if (!options_present) {
             buffer[0] = 0;
             buffer[1] = 4; // ACK
             if (bigfile_enabled) {
                 unsigned int bn = 0;
                 memcpy(&buffer[2], &bn, 4);
                 sendto(sockfd, buffer, header_length, 0, (struct sockaddr *)&client_addr, addr_len);
             } else {
                 buffer[2] = 0;
                 buffer[3] = 0;
                 sendto(sockfd, buffer, header_length, 0, (struct sockaddr *)&client_addr, addr_len);
             }
         }
         
         while (1) {
             int essai = 0, recvd;
             while (essai < MAX_ENVOI) {
                 recvd = recvfrom(sockfd, buffer, BUFFER_SIZE, 0, (struct sockaddr *)&client_addr, &addr_len);
                 if (bigfile_enabled) {
                     if (recvd >= 6 && buffer[1] == 3) break;
                 } else {
                     if (recvd >= 4 && buffer[1] == 3) break;
                 }
                 printf("Aucune réponse, attente du bloc %d (tentative %d)...\n", block_number, essai+1);
                 essai++;
             }
             if (essai == MAX_ENVOI) {
                 printf("Erreur : Client ne répond pas après %d tentatives pour le bloc %d\n", MAX_ENVOI, block_number);
                 break;
             }
             
             int received_block = 0;
             if (bigfile_enabled) {
                 unsigned int bn;
                 memcpy(&bn, &buffer[2], 4);
                 received_block = ntohl(bn);
             } else {
                 received_block = (buffer[2] << 8) | buffer[3];
             }
             if (received_block != block_number) {
                 printf("Bloc inattendu reçu : attendu=%d, reçu=%d\n", block_number, received_block);
                 continue;
             }
             
             fwrite(buffer + header_length, 1, recvd - header_length, file);
             
             // Envoi de l'ACK pour le bloc reçu
             buffer[0] = 0;
             buffer[1] = 4;
             if (bigfile_enabled) {
                 unsigned int bn = htonl(block_number);
                 memcpy(&buffer[2], &bn, 4);
                 sendto(sockfd, buffer, header_length, 0, (struct sockaddr *)&client_addr, addr_len);
             } else {
                 buffer[2] = (block_number >> 8) & 0xFF;
                 buffer[3] = block_number & 0xFF;
                 sendto(sockfd, buffer, header_length, 0, (struct sockaddr *)&client_addr, addr_len);
             }
             printf("ACK envoyé pour le bloc %d\n", block_number);
             if (recvd - header_length < 512) break;  // Dernier bloc
             block_number++;
         }
         
         fclose(file);
         pthread_rwlock_unlock(file_lock);
         printf("Fichier reçu et stocké : %s\n", fullpath);
    }
    
    close(sockfd);
    pthread_exit(NULL);
}

int main() {
    create_upload_dir();  // Création du dossier de réception
    
    int sockfd = socket(AF_INET, SOCK_DGRAM, 0);  // Création de la socket UDP
    if (sockfd < 0) {
        perror("Erreur de création de la socket");
        exit(EXIT_FAILURE);
    }
    
    struct sockaddr_in server_addr;
    memset(&server_addr, 0, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(SERVER_PORT);
    server_addr.sin_addr.s_addr = INADDR_ANY;
    
    if (bind(sockfd, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
        perror("Erreur de liaison de la socket");
        close(sockfd);
        exit(EXIT_FAILURE);
    }
    
    printf("Serveur TFTP en attente sur le port %d...\n", SERVER_PORT);
    
    // Boucle d'attente des requêtes initiales
    while (1) {
        info_client *client = malloc(sizeof(info_client));
        if (!client) {
            perror("Erreur d'allocation mémoire");
            continue;
        }
        
        client->addr_len = sizeof(client->client_addr);
        client->buffer_size = recvfrom(sockfd, client->buffer, BUFFER_SIZE, 0,
                                       (struct sockaddr *)&client->client_addr, &client->addr_len);
        if (client->buffer_size < 4) {
            free(client);
            continue;
        }
        
        pthread_t tid;
        if (pthread_create(&tid, NULL, handle_client, (void *)client) != 0) {
            perror("Erreur de création du thread");
            free(client);
            continue;
        }
        pthread_detach(tid);  // Détachement du thread pour qu'il se nettoie lui-même à la fin
    }
    
    close(sockfd);
    return 0;
}
