#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <errno.h>

#define BUFFER_SIZE 1024  // Suffisant pour contenir une requête complète
// OpCodes TFTP selon la norme RFC
#define OPCODE_RRQ   1
#define OPCODE_WRQ   2
#define OPCODE_DATA  3
#define OPCODE_ACK   4
#define OPCODE_ERROR 5
#define OPCODE_OACK  6

// Port utilisé (ici, 6969 pour éviter les privilèges root)
#define DEFAULT_PORT 6969
#define TEMPS 5       // Timeout en secondes
#define MAX_ENVOI 3   // Nombre maximal de retransmissions

// En mode standard, l'en-tête fait 4 octets ; en mode "bigfile", 6 octets.
#define NORMAL_ENTETE 4
#define BIGFILE_ENTETE 6

// Fonction d'affichage d'erreur et sortie
void gest_erreur(const char *message) {
    perror(message);
    exit(EXIT_FAILURE);
}

// Configure le timeout sur la socket via SO_RCVTIMEO
void configure_timeout(int sockfd, int timeout) {
    struct timeval tv;
    tv.tv_sec = timeout;
    tv.tv_usec = 0;
    if (setsockopt(sockfd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv)) < 0) {
        gest_erreur("Erreur de configuration du timeout");
    }
}

/*
     Envoie une requête de lecture (RRQ) au serveur pour récupérer le fichier demandé.
     La requête inclut l'option "bigfile" avec la valeur "1". Si le serveur négocie l'option
     en renvoyant un OACK, le client envoie ensuite l'ACK correspondant pour le bloc 0 et passe
     en mode bigfile (en-tête étendu à 6 octets).
    
     La fonction a été modifiée pour traiter les paquets ERROR renvoyés par le serveur (par exemple,
     si le fichier n'est pas trouvé).
 */
void send_rrq(int sockfd, struct sockaddr_in *server_addr, const char *filename) {
    char buffer[BUFFER_SIZE];
    socklen_t server_addr_len = sizeof(*server_addr);
    int use_bigfile = 0;  // Par défaut, mode standard | flag pour le mode "bigfile"

    // Configuration du timeout sur la socket
    configure_timeout(sockfd, TEMPS);

    // Construction de la requête RRQ avec option "bigfile":
    // Format : [0][OPCODE_RRQ][filename]\0["octet"]\0["bigfile"]\0["1"]\0
    int rrq_len = snprintf(buffer, sizeof(buffer), "%c%c%s%c%s%c%s%c%s%c",
                             0, OPCODE_RRQ, filename, 0, "octet", 0, "bigfile", 0, "1", 0);
    int essai = 0;
    while (essai < MAX_ENVOI) {
        if (sendto(sockfd, buffer, rrq_len, 0, (struct sockaddr *)server_addr, server_addr_len) < 0) {
            perror("Erreur lors de l'envoi de la requête RRQ");
            exit(1);
        }
        printf("Requête RRQ envoyée (tentative %d) pour le fichier : %s\n", essai + 1, filename);

        // Attente de la première réponse du serveur
        int recv_len = recvfrom(sockfd, buffer, BUFFER_SIZE, 0,
                                (struct sockaddr *)server_addr, &server_addr_len);
        if (recv_len >= 0) {
            // Si le serveur négocie l'option, il renvoie un OACK
            if (buffer[1] == OPCODE_OACK) {
                // on passe le flag à 1 pour activer le mode "bigfile"
                use_bigfile = 1;
                printf("OACK reçu, option bigfile activée.\n");
                // Envoi de l'ACK pour l'OACK (bloc 0) avec en-tête étendu
                char ack[BIGFILE_ENTETE];
                ack[0] = 0;
                ack[1] = OPCODE_ACK;
                unsigned int a = 0;
                unsigned int nblk0 = htonl(a);
                memcpy(&ack[2], &nblk0, 4);
                if (sendto(sockfd, ack, BIGFILE_ENTETE, 0, (struct sockaddr *)server_addr, server_addr_len) < 0) {
                    gest_erreur("Erreur lors de l'envoi de l'ACK pour l'OACK");
                }
                // Attente du premier paquet DATA ou ERROR
                recv_len = recvfrom(sockfd, buffer, BUFFER_SIZE, 0,
                                    (struct sockaddr *)server_addr, &server_addr_len);
            }
            break; // Une réponse a été reçue
        }
        printf("Aucune réponse du serveur, nouvelle tentative...\n");
        essai++;
    }
    if (essai == MAX_ENVOI) {
        printf("Erreur : le serveur ne répond pas après %d tentatives.\n", MAX_ENVOI);
        exit(1);
    }

    // Vérification si le serveur a renvoyé une erreur
    if (buffer[1] == OPCODE_ERROR) {
        fprintf(stderr, "Erreur reçue du serveur : %s\n", buffer + 4);
        exit(EXIT_FAILURE);
    }

    // Création du fichier local pour écrire les données reçues
    FILE *file = fopen(filename, "wb");
    if (!file) {
        perror("Erreur lors de l'ouverture du fichier local");
        exit(1);
    }
    // on détermine ici la taille de l'en-tête à utiliser pour les paquets DATA et ACK
    int header_size = use_bigfile ? BIGFILE_ENTETE : NORMAL_ENTETE;
    int block_number = 1;
    while (1) {
        essai = 0;
        int recv_len;
        // Réception d'un bloc DATA
        while (essai < MAX_ENVOI) {
            recv_len = recvfrom(sockfd, buffer, BUFFER_SIZE, 0,
                                 (struct sockaddr *)server_addr, &server_addr_len);
            if (recv_len >= header_size)
                break;
            printf("Timeout lors de la réception du bloc %d, tentative %d...\n", block_number, essai + 1);
            essai++;
        }
        if (essai == MAX_ENVOI) {
            printf("Erreur : échec de réception du bloc %d après %d tentatives.\n", block_number, MAX_ENVOI);
            fclose(file);
            exit(1);
        }

        // Vérification d'un paquet ERROR éventuel
        if (buffer[1] == OPCODE_ERROR) {
            fprintf(stderr, "Erreur reçue du serveur : %s\n", buffer + 4);
            fclose(file);
            exit(EXIT_FAILURE);
        }

        int opcode, bloc_recu;  // Déclaration des variables pour l'opcode et le numéro de bloc reçu
        if (use_bigfile) {  // Si le mode "bigfile" est activé
            opcode = buffer[1];  // Récupère l'opcode du paquet
            unsigned int b;  // Variable pour stocker le numéro de bloc en mode "bigfile"
            memcpy(&b, &buffer[2], 4);  // Copie les 4 octets du numéro de bloc car il est sur 32 bits
            bloc_recu = ntohl(b);  // Convertit le numéro de bloc en ordre d'octets hôte
        } else {  // Si on a pas de bigfile
            opcode = buffer[1];  // Récupère l'opcode du paquet
            unsigned short b;  // Variable pour stocker le numéro de bloc en mode standard
            memcpy(&b, &buffer[2], 2);  // Copie les 2 octets du numéro de bloc depuis le buffer
            bloc_recu = ntohs(b);  // Convertit le numéro de bloc en ordre d'octets hôte
        }
        if (opcode != OPCODE_DATA || bloc_recu != block_number) {  // Vérifie si l'opcode est DATA et si le numéro de bloc est correct
            printf("Bloc inattendu reçu : opcode=%d, block=%d (attendu=%d)\n", opcode, bloc_recu, block_number);  // Affiche un message d'erreur si le bloc est inattendu
            continue;  // Passe à l'itération suivante de la boucle
        }

        fwrite(buffer + header_size, 1, recv_len - header_size, file);
        printf("Reçu et écrit le bloc %d\n", block_number);

        // Vérifie si le mode "bigfile" est activé
        if (use_bigfile) {
            // Prépare un ACK avec un en-tête étendu (6 octets)
            char ack[BIGFILE_ENTETE];
            ack[0] = 0;  // Premier octet de l'en-tête
            ack[1] = OPCODE_ACK;  // Opcode pour ACK
            unsigned int bn = htonl(block_number);  // Convertit le numéro de bloc en ordre d'octets réseau (32 bits)
            memcpy(&ack[2], &bn, 4);  // Copie le numéro de bloc dans l'en-tête

            // Envoie l'ACK au serveur
            if (sendto(sockfd, ack, BIGFILE_ENTETE, 0, (struct sockaddr *)server_addr, server_addr_len) < 0) {
                // Affiche une erreur si l'envoi échoue
                perror("Erreur lors de l'envoi de l'ACK");
                fclose(file);  // Ferme le fichier
                exit(1);  // Quitte le programme avec un code d'erreur
            }
        } else {
            // Prépare un ACK avec un en-tête standard (4 octets)
            char ack[NORMAL_ENTETE];
            ack[0] = 0;  // Premier octet de l'en-tête
            ack[1] = OPCODE_ACK;  // Opcode pour ACK
            unsigned short bn = htons((unsigned short)block_number);  // Convertit le numéro de bloc en ordre d'octets réseau (16 bits)
            memcpy(&ack[2], &bn, 2);  // Copie le numéro de bloc dans l'en-tête

            // Envoie l'ACK au serveur
            if (sendto(sockfd, ack, NORMAL_ENTETE, 0, (struct sockaddr *)server_addr, server_addr_len) < 0) {
                // Affiche une erreur si l'envoi échoue
                perror("Erreur lors de l'envoi de l'ACK");
                fclose(file);  // Ferme le fichier
                exit(1);  // Quitte le programme avec un code d'erreur
            }
        }
        printf("ACK envoyé pour le bloc %d\n", block_number);

        // Si le paquet DATA contient moins de 512 octets de données, c'est le dernier bloc
        if (recv_len - header_size < 512) {
            printf("Transfert terminé. Dernier bloc reçu : %d\n", block_number);
            break;
        }
        block_number++;
    }

    fclose(file);
    printf("Transfert RRQ terminé pour %s:%d\n",
           inet_ntoa(server_addr->sin_addr), ntohs(server_addr->sin_port));
}

/*
    Envoie une requête d'écriture (WRQ) pour transférer le fichier spécifié.
    La requête inclut l'option "bigfile". Si le serveur négocie l'option en renvoyant un OACK,
    le client envoie l'ACK pour le bloc 0 et utilise un en-tête étendu (6 octets) pour les paquets DATA et ACK.
 */
void send_wrq(int sockfd, struct sockaddr_in *server_addr, const char *filename) {
    FILE *file = fopen(filename, "rb");
    if (!file) {
        perror("Erreur : Impossible d'ouvrir le fichier à envoyer");
        exit(EXIT_FAILURE);
    }

    char buffer[BUFFER_SIZE];
    socklen_t addr_len = sizeof(*server_addr);
    int block_number = 0;
    int essai;
    ssize_t bytes_received;

    // Construction de la requête WRQ avec option "bigfile":
    // Format : [0][OPCODE_WRQ][filename]\0["octet"]\0["bigfile"]\0["1"]\0
    buffer[0] = 0;
    buffer[1] = OPCODE_WRQ;
    int pos = 2;

    // Copie du nom de fichier
    pos += snprintf(&buffer[pos], sizeof(buffer) - pos, "%s", filename) + 1;

    // Copie du mode "octet"
    pos += snprintf(&buffer[pos], sizeof(buffer) - pos, "%s", "octet") + 1;

    // Copie de l'option "bigfile"
    pos += snprintf(&buffer[pos], sizeof(buffer) - pos, "%s", "bigfile") + 1;

    // Copie de la valeur de l'option "1"
    pos += snprintf(&buffer[pos], sizeof(buffer) - pos, "%s", "1") + 1;

    int len = pos;  // Longueur totale de la requête

    essai = 0;  // Initialisation du compteur de tentatives
    int use_bigfile = 0;  // Indicateur pour le mode "bigfile", initialisé à 0 (désactivé)
    while (essai < MAX_ENVOI) {  // Boucle de tentatives d'envoi de la requête WRQ
        // Envoi de la requête WRQ au serveur
        if (sendto(sockfd, buffer, len, 0, (struct sockaddr *)server_addr, addr_len) < 0) {
            // Affiche une erreur si l'envoi échoue
            perror("Erreur d'envoi de WRQ");
            fclose(file);  // Ferme le fichier
            exit(EXIT_FAILURE);  // Quitte le programme avec un code d'erreur
        }
        printf("Requête WRQ envoyée (tentative %d) pour le fichier : %s\n", essai + 1, filename);

        // Attente de la réponse du serveur
        bytes_received = recvfrom(sockfd, buffer, BUFFER_SIZE, 0, (struct sockaddr *)server_addr, &addr_len);
        if (bytes_received > 0) {
            // Vérifie si le serveur a renvoyé un OACK (Option Acknowledgment)
            if (buffer[1] == OPCODE_OACK) {
                use_bigfile = 1;  // Active le mode "bigfile"
                printf("OACK reçu, option bigfile activée.\n");

                // Prépare un ACK pour l'OACK avec un en-tête étendu (6 octets)
                char ack[BIGFILE_ENTETE];
                ack[0] = 0;  // Premier octet de l'en-tête
                ack[1] = OPCODE_ACK;  // Opcode pour ACK
                unsigned int a = 0;  // Numéro de bloc 0
                unsigned int nblk0 = htonl(a);  // Convertit le numéro de bloc en ordre d'octets réseau (32 bits)
                memcpy(&ack[2], &nblk0, 4);  // Copie le numéro de bloc dans l'en-tête

                // Envoie l'ACK pour l'OACK au serveur
                if (sendto(sockfd, ack, BIGFILE_ENTETE, 0, (struct sockaddr *)server_addr, addr_len) < 0) {
                    // Affiche une erreur si l'envoi échoue
                    gest_erreur("Erreur lors de l'envoi de l'ACK pour l'OACK");
                }
            }
            break;  // Sort de la boucle si une réponse a été reçue
        }
        printf("Aucune réponse du serveur, nouvelle tentative...\n");
        essai++;  // Incrémente le compteur de tentatives
    }
    if (essai == MAX_ENVOI) {
        fprintf(stderr, "Erreur : le serveur ne répond pas après %d tentatives.\n", MAX_ENVOI);
        fclose(file);
        exit(EXIT_FAILURE);
    }

    block_number = 1;
    int header_size = use_bigfile ? BIGFILE_ENTETE : NORMAL_ENTETE;
    size_t bytes_read;
    while ((bytes_read = fread(buffer + header_size, 1, 512, file)) > 0) {
        buffer[0] = 0;
        buffer[1] = OPCODE_DATA;
        if (use_bigfile) {
            unsigned int bn = htonl(block_number);
            memcpy(&buffer[2], &bn, 4);
        } else {
            unsigned short bn = htons((unsigned short)block_number);
            memcpy(&buffer[2], &bn, 2);
        }
        int packet_size = header_size + bytes_read;  // Calcule la taille totale du paquet à envoyer
        essai = 0;  // Initialisation du compteur de tentatives
        while (essai < MAX_ENVOI) {  // Boucle de tentatives d'envoi du paquet de données
            if (sendto(sockfd, buffer, packet_size, 0, (struct sockaddr *)server_addr, addr_len) < 0) {
                // Affiche une erreur si l'envoi échoue
                perror("Erreur d'envoi des données");
                fclose(file);  // Ferme le fichier
                exit(EXIT_FAILURE);  // Quitte le programme avec un code d'erreur
            }
            // Attente de l'ACK du serveur
            bytes_received = recvfrom(sockfd, buffer, BUFFER_SIZE, 0, (struct sockaddr *)server_addr, &addr_len);
            if (bytes_received > 0) {
                int opcode_ack = buffer[1];  // Récupère l'opcode de la réponse
                int bloc_recu = 0;  // Initialisation du numéro de bloc reçu
                if (use_bigfile) {
                    unsigned int bn;
                    memcpy(&bn, &buffer[2], 4);  // Copie les 4 octets du numéro de bloc
                    bloc_recu = ntohl(bn);  // Convertit le numéro de bloc en ordre d'octets hôte
                } else {
                    unsigned short bn;
                    memcpy(&bn, &buffer[2], 2);  // Copie les 2 octets du numéro de bloc
                    bloc_recu = ntohs(bn);  // Convertit le numéro de bloc en ordre d'octets hôte
                }
                if (opcode_ack == OPCODE_ACK && bloc_recu == block_number) {
                    block_number++;  // Incrémente le numéro de bloc pour le prochain envoi
                    break;  // Sort de la boucle si l'ACK est reçu pour le bloc courant
                } else if (opcode_ack == OPCODE_ERROR) {
                    // Affiche une erreur si un paquet d'erreur est reçu
                    fprintf(stderr, "Erreur reçue du serveur : %s\n", buffer + 4);
                    fclose(file);  // Ferme le fichier
                    return;  // Quitte la fonction
                }
            }
            // Si un timeout ou une autre erreur de réception se produit
            if (errno == EAGAIN || errno == EWOULDBLOCK) {
                fprintf(stderr, "Timeout atteint pour l'ACK du bloc %d. Réessai...\n", block_number);
                essai++;  // Incrémente le compteur de tentatives
            } else {
                // Affiche une erreur si une autre erreur de réception se produit
                perror("Erreur lors de la réception de l'ACK");
                fclose(file);  // Ferme le fichier
                exit(EXIT_FAILURE);  // Quitte le programme avec un code d'erreur
            }
        }
        if (essai == MAX_ENVOI) {
            fprintf(stderr, "Nombre maximal de retransmissions atteint pour le bloc %d.\n", block_number);
            fclose(file);
            return;
        }
        printf("ACK reçu pour le bloc %d\n", block_number - 1);
    }

    fclose(file);
    printf("Fichier %s envoyé avec succès.\n", filename);
}

int main(int argc, char *argv[]) {
    if (argc < 4) {
        fprintf(stderr, "Usage: %s <server_ip> <mode> <filename>\n", argv[0]);
        fprintf(stderr, "<mode>: 'put' ou 'get'\n");
        exit(EXIT_FAILURE);
    }

    const char *server_ip = argv[1];
    const char *mode = argv[2]; // "put" ou "get"
    const char *filename = argv[3]; // nom du fichier

    int sockfd;
    struct sockaddr_in server_addr;

    if ((sockfd = socket(AF_INET, SOCK_DGRAM, 0)) < 0) {
        gest_erreur("Erreur de création du socket");
    }

    configure_timeout(sockfd, TEMPS);

    memset(&server_addr, 0, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(DEFAULT_PORT);
    if (inet_pton(AF_INET, server_ip, &server_addr.sin_addr) <= 0) {
        gest_erreur("Adresse IP invalide");
    }

    if (strcmp(mode, "get") == 0) {
        send_rrq(sockfd, &server_addr, filename);
    } else if (strcmp(mode, "put") == 0) {
        send_wrq(sockfd, &server_addr, filename);
    } else {
        fprintf(stderr, "Mode invalide : 'get' ou 'put'\n");
        close(sockfd);
        exit(EXIT_FAILURE);
    }

    close(sockfd);
    return 0;
}
